#include <unistd.h>

int tcsetpgrp( int fd, pid_t pgrp ) {
    return 0;
}
