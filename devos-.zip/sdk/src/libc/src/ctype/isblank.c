
 

#include <ctype.h>

int isblank( int c ) {
    return ( c == ' ' || c == '\t' );
}
