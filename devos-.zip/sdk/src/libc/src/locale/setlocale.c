
 

#include <locale.h>
#include <stdlib.h>

char* setlocale( int category, const char* locale ) {
    /* TODO */

    return NULL;
}
