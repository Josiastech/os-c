
 

#include <signal.h>

int killpg( int pgrp, int signal ) {
    return -1;
}
