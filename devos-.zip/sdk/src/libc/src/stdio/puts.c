
 

#include <stdio.h>

int puts( const char* s ) {
    printf("%s\n", s );
    //fflush( stdout );

    return 0;
}
