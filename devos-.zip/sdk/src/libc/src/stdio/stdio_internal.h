
 

#ifndef _STDIO_INTERNAL_H_
#define _STDIO_INTERNAL_H_

int __set_stream_flags( FILE* stream, int new_flags );

#endif /* _STDIO_INTERNAL_H_ */
