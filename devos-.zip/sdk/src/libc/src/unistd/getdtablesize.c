#include <unistd.h>

int getdtablesize( void ) {
    return 1024;
}
