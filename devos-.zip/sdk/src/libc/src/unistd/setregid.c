#include <unistd.h>

int setregid( gid_t rgid, gid_t egid ) {
    return 0;
}
