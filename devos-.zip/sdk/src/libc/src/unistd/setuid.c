#include <unistd.h>

int setuid( uid_t uid ) {
    return 0;
}
