#include <unistd.h>

int setpgid( pid_t pid, pid_t pgid ) {
    return 0;
}
