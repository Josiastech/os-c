
 

#include <stdlib.h>

long long llabs( long long j ) {
    if ( j < 0 ) {
        return -j;
    } else {
        return j;
    }
}
