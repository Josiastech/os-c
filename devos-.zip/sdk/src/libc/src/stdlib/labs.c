
 

#include <stdlib.h>

long labs( long j ) {
    if ( j < 0 ) {
        return -j;
    } else {
        return j;
    }
}
