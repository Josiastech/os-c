

#ifndef _SYS_TIME_H_
#define _SYS_TIME_H_

#include <time.h>

int gettimeofday( struct timeval* tv, struct timezone* tz );

#endif // _SYS_TIME_H_
