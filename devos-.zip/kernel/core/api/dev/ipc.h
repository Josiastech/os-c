#ifndef __API_IPC__
#define __API_IPC__

#define STDIPC_FILENO	3
#define SIGIPC		SIGUSR1


//iotcl
#define API_TTY_SWITCH_SCREEN	0xff52



#endif
